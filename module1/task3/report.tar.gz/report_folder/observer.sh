#!/bin/bash

CONFIG_FILE="observer.conf"
LOG_FILE="observer.log"

log_message() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> $LOG_FILE
}

if [[ ! -f $CONFIG_FILE ]]; then
	log_message "Ошибка: файл конфигурации $CONFIG_FILE не найден"
	exit 1
fi

while IFS= read -r script || [[ -n "$script" ]]; do
	[[ -z "$script" ||"$script" =~ ^[[:space:]]*# ]] && continue
	script=$(echo "$script" | xargs)
	if [[ ! -f "$script" ]]; then
		log_message "Ошибка: скрипт $script не найден"
		continue
	fi
	
	script_name=$(basename "$script")
	if pgrep -f "$script_name" > /dev/null; then
		log_message "Скрипт $script_name уже запущен"
	else
		chmod +x "$script"
		nohup "$script" > /dev/null 2>&1 &
		log_message "Перезапущен скрипт $script_name (PID: $!)"
	fi

done < "$CONFIG_FILE"
