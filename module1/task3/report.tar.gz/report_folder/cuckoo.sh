#! /bin/bash

mkdir -p /tmp/run

PIPE="/tmp/run/cuckoo.pid"
rm -f $PIPE
mkfifo $PIPE
chmod 666 $PIPE

LOG="cuckoo.log"

log_message() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') $1" >> $LOG
}

log_message "Startup!"

cleanup() {
	log_message "Shutdown!"
	rm -f $PIPE
	exit 0
}

trap cleanup SIGTERM SIGINT

while true; do
	if read line < $PIPE; then
	log_message "Recieved: $line"
	if [[ $line =~ ^([^[]+)\[([0-9]+)\]:\ how\ much\ time\ do\ I\ have\?$ ]]; then
		NAME="${BASH_REMATCH[1]}"
		PID="${BASH_REMATCH[2]}"
		N=$((RANDOM % 9 + 2))

		log_message "$NAME[$PID] $N"
			
		echo "$PID $N" > $PIPE
	fi
	fi
done 

