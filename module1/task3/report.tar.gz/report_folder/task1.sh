#!/bin/bash

SCRIPT_NAME=$(basename "$0")
if [[ "$SCRIPT_NAME" == "template_task.sh" ]]; then
	echo "я бригадир, сам не работаю"
	exit 1
fi

REPORT_FILE="report_${SCRIPT_NAME%.sh}.log"

PIPE="/tmp/run/cuckoo.pid"

log_message() {
	echo "$(date '+%Y-%m-%d %H:%M:%S') [$$] $1" >> $REPORT_FILE
}

log_message "Скрипт запущен"

if [[ ! -p $PIPE ]]; then
	log_message "Ошибка: канал $PIPE не существует"
	exit 1
fi

REQUEST="$SCRIPT_NAME[$$]: how much time do I have?"
echo "$REQUEST" > $PIPE

MY_PID=$$
while true; do
	if read -t 5 line < $PIPE; then
		if [[ "$line" =~ ^$MY_PID[[:space:]]+([0-9]+)$ ]]; then
			N="${BASH_REMATCH[1]}"
			sleep $N
			log_message "Скрипт завершился, работал $N секунд"
			exit 0
		fi
	fi
done


